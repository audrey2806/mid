class inheritance{
	String nama;
	public int tiperumah;
	public int pemakaian;
	public int bayar;
	public int totalharga;	
}