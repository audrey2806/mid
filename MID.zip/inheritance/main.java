import java.util.Scanner;

class main{
	public static void main(String[]args){
			proses p = new proses();
			
		p.input();
		p.pilihan();
		p.pembayaran();
		p.cetak();
		
		
	}
		
}
	